## Image-getter

Simple demo project to brush up on Web Extensions and js Promises. Basically this is just re-creating the "Open Link in New Tab" function in most browsers. Eventually will be merged into another project that would get your original sized images from an instagram popup (since they're small, scaled and standard browser "View Image" functionality won't work), and open those in a new tab.
